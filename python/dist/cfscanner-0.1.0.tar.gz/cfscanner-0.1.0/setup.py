# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cfscanner']

package_data = \
{'': ['*']}

install_requires = \
['pysocks>=1.7.1,<2.0.0', 'requests>=2.28.2,<3.0.0']

entry_points = \
{'console_scripts': ['cfscanner = cfscanner.cfFindIP:parse_args']}

setup_kwargs = {
    'name': 'cfscanner',
    'version': '0.1.0',
    'description': 'Cloud Flare scanner',
    'long_description': '# CFScanner - Python\n\nThe script is designed to scan Cloudflare\'s edge IPs and locate ones that are viable for use with v2ray/xray. It aims to identify edge IPs that are accessible and not blocked.\n\n# Dependencies\n\n* Linux\n* Python (>=3.6)\n* Libraries \n    - requests\n    - pysocks\n\n# Installings\n\n* Install prerequisites\n```bash\nsudo apt update && sudo apt install python3-pip git -y\n```\n* Clone the project\n```bash\ngit clone https://github.com/MortezaBashsiz/CFScanner.git\n```\n* Change directory\n```bash\ncd CFScanner/python/\n```\n* Install required packages\n```bash\npip install -r ./requirements.txt\n```\n* create a config json file (e.g., myconfig.json) with the following content. replace the values with your own!\n```json\n{\n\t"id": "248ecb72-89cf-5be7-923f-b790fca681c5",\n\t"host": "scherehtzhel01.sudoer.net",\n\t"port": "443",\n\t"path": "api01",\n\t"serverName": "248ecb72-89cf-5be7-923f-b790fca681c5.sudoer.net"\n}\n```\n\n# Executing program\n\n## **How to run**\n* To run without providing a subnets (CIDRs) file and using 8 threads: \n```bash\npython3 cfFindIP.py --threads 8 --config ./myconfig.json\n```\n* To run on a list of subnets (recommended). Each line\n```bash\npython3 cfFindIP.py --threads 8 --config ./myconfig.json --subnets ./mysubnets.selection\n```\n* To run with a minimum acceptable download speed (in KBps)\n```bash\npython3 cfFindIP.py --threads 8 --config ./myconfig.json --subnets ./mysubnets.selection --download-speed 100\n```\n* To run with a minimum acceptable download and upload speed (in KBps)\n```bash\npython3 cfFindIP.py --upload-test --threads 8 --config ./myconfig.json --subnets ./mysubnets.selection --download-speed 100 --upload-speed 25\n```\n* To run and try each IP multiple (3 in this case) times. An IP is marked ok if it passes all the tests.\n```bash\npython3 cfFindIP.py --upload-test --threads 8 --config ./myconfig.json --subnets ./mysubnets.selection --download-speed 100 --upload-speed 25 --tries 3\n```\n\n\nEach line of the subnets file must be a Cloudflare subnets in CIDR notation or a single IP:\n```\n1.0.0.0/24\n108.162.218.0/24\n108.162.236.0/22\n162.158.8.0/21\n162.158.60.0/24\n162.158.82.12\n...\n```\n\n## **Arguments:**\n**--threads|-thr**: Number of threads to use for parallel computing<br>\n**--config|-c**: The path to the config file. For confg file example, see [ClientConfig.json](https://github.com/MortezaBashsiz/CFScanner/blob/main/bash/ClientConfig.json)<br>\n**--subnets|-sn**: The path to the custom subnets file. each line<br> should be in the form of ip.ip.ip.ip/subnet_mask. If not provided, the program will read the cidrs from asn lookup <br>\n**--tries**: Number of times to try each IP. An IP is marked as OK if **all** tries are successful. <br>\n**--download-speed**: Minimum acceptable download speed in kilobytes per second <br>\n**--upload-test**: If True, upload test will be conducted as well <br>\n**--upload-speed**: Mimimum Maximum acceptable upload speed in kilobytes per second <br>\n**--download-time**: Maximum (effective, excluding latency) time to spend for each download. <br> \n**--upload-time**: Maximum (effective, excluding latency) time to spend for each upload <br>\n**--download-latency**: Maximum allowed latency (seconds) for download <br>\n**--upload-latency**: Maximum allowed latency (seconds) for upload <br>\n\n---\n\n## Remarks\n* In the current version, an IP is marked "OK", only if it passes all tries of the experiment\n* The size of the file for download is determined based on the arguments ``download-speed`` and ``download-time`` (similar for upload as well). Therefore, it is recommended to choose these parameters carefully based on your expectations, internet speed and the number of threads being used\n\n# **Results**\nThe results will be stored in the ``results`` directory. Each line of the generated **csv** file includes a Cloudflare edge ip together with the following values:\n* ``avg_download_speed\n``: Average download speed in mbps\n* ``avg_upload_speed``: Average upload speed in mbps\n* ``avg_download_latency``: Average download latency in ms\n* ``avg_upload_latency``: Average upload latency in ms\n* ``avg_download_jitter``: Average jitter during downloads in ms\n* ``avg_upload_jitter``: Average jitter during uploads in ms\n* ``download_speed_1,...,n_tries``: Values of download speeds in mbps for each download \n* ``upload_speed_1,...,n_ties``: Values of download speeds in mbps for each upload\n* ``download_latency_1,...,n_tries``: Values of download latencies in ms\n* ``download_latency_1,..._n_tries``: Values of upload latencies in ms\n\n\n---\n\nFor each time running the code, a result file is generated in the result folder with the datetime string to avoid overwriting (e.g, ``20230226_180502_result.csv``)\n\n\n# Authors\n\nContributors names and contact info\n\n* [Tempookian](https://github.com/tempookian)  \n* [Morteza Bashsiz](https://github.com/MortezaBashsiz/)\n\n# Version History\n\n* 0.1\n    * Initial Release\n\n# License\n\n\n\n',
    'author': 'MortezaBashsiz',
    'author_email': 'morteza.bashsiz@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
