# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cfscanner']

package_data = \
{'': ['*']}

install_requires = \
['pysocks>=1.7.1,<2.0.0', 'requests>=2.28.2,<3.0.0']

entry_points = \
{'console_scripts': ['cfscanner = cfscanner.cfFindIP:parse_args']}

setup_kwargs = {
    'name': 'cfscanner',
    'version': '0.1.0',
    'description': 'Cloud Flare scanner',
    'long_description': '# CFScanner - Python\n\nThe script is designed to scan Cloudflare\'s edge IPs and locate ones that are viable for use with v2ray/xray. It aims to identify edge IPs that are accessible and not blocked.\n\n<!-- ## Description\n\nAn in-depth paragraph about your project and overview of use. -->\n\n# Dependencies\n\n* Linux\n* Python (>=3.6)\n* Libraries \n    - requests\n    - pysocks\n\n# Installing\n\n* Install prerequisites\n```bash\nsudo apt update && sudo apt install python3-pip python3-venv git -y\n```\n* Clone the project\n```bash\ngit clone https://github.com/MortezaBashsiz/CFScanner.git\n```\n* Change directory\n```bash\ncd CFScanner\n```\n* Install required packages\n```bash\npip install -r ./requirements.txt\n```\n* create a config json file (e.g., myconfig.json) with the following content. replace the values with your own!\n```json\n{\n\t"id": "User\'s UUID",\n\t"Host": "Host address which is behind Cloudflare",\n\t"Port": "Port which you are using behind Cloudflare on your origin server",\n\t"path": "Websocket endpoint like api20",\n\t"serverName": "SNI",\n   \t"subnetsList": "https://raw.githubusercontent.com/MortezaBashsiz/CFScanner/main/bash/cf.local.iplist"\n}\n```\n\n# Executing program\n\n## **How to run**\n* To run without providing a subnets (CIDRs) file and using 8 threads: \n```bash\npython3 cfFindIP.py --threads 8 --config ./myconfig.json\n```\n* To run on a list of subnets (recommended). Each line\n```bash\npython3 cfFindIP.py --threads 8 --config ./myconfig.json --subnets ./mysubnets.selection\n```\n* To run with a minimum acceptable download speed (in KBps)\n```bash\npython3 cfFindIP.py --threads 8 --config ./myconfig.json --subnets ./mysubnets.selection --download-speed 100\n```\n* To run with a minimum acceptable download and upload speed (in KBps)\n```bash\npython3 cfFindIP.py --upload-test --threads 8 --config ./myconfig.json --subnets ./mysubnets.selection --download-speed 100 --upload-speed 25\n```\n* To run and try each IP multiple (3 in this case) times. An IP is marked ok if it passes all the tests.\n```bash\npython3 cfFindIP.py --upload-test --threads 8 --config ./myconfig.json --subnets ./mysubnets.selection --download-speed 100 --upload-speed 25 --tries 3\n```\n\n\nEach line of the subnets file must be a Cloudflare subnets in CIDR notation or a single IP:\n```\n1.0.0.0/24\n108.162.218.0/24\n108.162.236.0/22\n162.158.8.0/21\n162.158.60.0/24\n162.158.82.12\n...\n```\n\n<!-- ## **positional arguments:**\n* **threads**: Number of threads to use for parallel computing\n* **config-path**: The path to the config file. For confg file example, see [config.sample](https://github.com/tempookian/CFScanner/blob/python/python/config.sample)\n* **subnets-path**: (optional) The path to the custom subnets file. each line should be in the form of ip.ip.ip.ip/subnet_mask. If not provided, the program will read the cidrs from asn lookup\n\n## **keyword arguments:**\n* **--min-dl-speed**: Minimum acceptable download speed in KBps (default = 50)\n\n---\n\n## **Results:**\nThe results will be stored in the results directory. Each line of the results files includes a Cloudflare edge ip together with the respective response time in milliseconds, e.g., \n\n```\n153 104.16.126.37\n154 104.21.47.40\n154 104.18.38.111\n157 104.18.38.38\n159 104.16.126.42\n159 104.17.223.179\n...\n```\n\nTwo files are stored for each (complete) run of the script\n* interim results file (e.g., ``20230226_180502_interim_result.txt``)\n    - Includes the unsorted intermediate results. Useful in case the run is not complete.  \n* final results file (e.g., ``20230226_180502_final_result.txt``)\n  * Includes the final sorted results. The results are sorted ascendingly based on the response time of the edge ips.  -->\n\n\n<!-- ## Help\n\nAny advise for common problems or issues.\n```\ncommand to run if program contains helper info\n``` -->\n\n# Authors\n\nContributors names and contact info\n\n* [Tempookian](https://github.com/tempookian)  \n* [Morteza Bashsiz](https://github.com/MortezaBashsiz/)\n\n# Version History\n\n* 0.1\n    * Initial Release\n\n# License\n\n\n<!-- ## Acknowledgments\n\nInspiration, code snippets, etc.\n* [awesome-readme](https://github.com/matiassingers/awesome-readme)\n* [PurpleBooth](https://gist.github.com/PurpleBooth/109311bb0361f32d87a2)\n* [dbader](https://github.com/dbader/readme-template)\n* [zenorocha](https://gist.github.com/zenorocha/4526327)\n* [fvcproductions](https://gist.github.com/fvcproductions/1bfc2d4aecb01a834b46) -->\n\n',
    'author': 'MortezaBashsiz',
    'author_email': 'morteza.bashsiz@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
